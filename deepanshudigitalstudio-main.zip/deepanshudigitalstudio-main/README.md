# Deepanshu Studio

Create a premium, modern and highly creative portfolio website for Deepanshu Digital Studio.

The website is for a professional creative designer providing:

* Graphic Design
* Video Editing
* Advertisement Creation
* Website Creation
* Social Media Creative Content
* Branding & Promotional Content

DESIGN STYLE

Create a premium dark, cinematic creative-agency style.

* Black/deep charcoal background
* White typography
* Premium subtle accent color
* Smooth animations
* Glassmorphism cards where appropriate
* Large bold typography
* Clean spacing
* Premium hover effects
* Fully responsive
* Mobile-first
* Fast loading
* Do not make it look like a basic template

HERO SECTION

Show:

DEEPANSHU DIGITAL STUDIO

Creative Design. Powerful Visuals. Digital Experiences.

Description:

“I create eye-catching designs, engaging videos, powerful advertisements and professional websites that help brands stand out.”

Buttons:

View My Work
Book a Project

Add an attractive animated creative visual related to graphic design, video editing, advertising and websites.

SERVICES

Create premium service cards for:

🎨 Graphic Design
Posters, social media designs, thumbnails, branding and promotional graphics.

🎬 Video Editing
Reels, promotional videos, cinematic edits and short-form content.

📢 Advertisement Creation
Creative digital ads, promotional advertisements, product ads and social media campaigns.

🌐 Website Creation
Modern, responsive and professional websites for businesses, brands and creators.

📱 Social Media Content
Instagram posts, stories, reels creatives, thumbnails and social media visuals.

✨ Branding
Logos, brand identity, promotional material and visual identity.

MY PROJECTS

Create a beautiful portfolio section with filters:

All | Graphic Design | Video | Ads | Websites | Branding

Each project should contain:

* Project image/video thumbnail
* Project name
* Category
* Short description
* View Project button

Make the portfolio easy to update later. I should be able to add new projects, images/videos, titles, categories and descriptions without redesigning the website.

ABOUT ME

Heading:

Turning Ideas Into Visual Experiences

Write a professional introduction about Deepanshu as a graphic designer, video editor, website creator and digital creator.

Skills:

Graphic Design • Video Editing • Ads • Websites • Branding • Social Media

Add a professional profile-image placeholder that can be replaced later.

WHY WORK WITH ME

Create four premium points:

⚡ Creative & Original
🎯 Focused on Your Brand
🚀 Fast & Professional
💎 Quality-First Work

PROCESS

Create a stylish 4-step timeline:

01 — Discuss
02 — Plan
03 — Create
04 — Deliver

BOOK A PROJECT

Create a professional project booking form.

Fields:

* Name
* Email
* WhatsApp Number
* Service Required
* Project Details
* Budget
* Preferred Deadline

Service dropdown:

* Graphic Design
* Video Editing
* Advertisement
* Website
* Branding
* Social Media Content
* Other

Button:

Send Project Request

WHATSAPP FUNCTIONALITY

Use my WhatsApp number:

+91 7876728918

Store it in one easy-to-edit configuration variable:

WHATSAPP_NUMBER = "917876728918"

Do not create or use any other number.

When a visitor submits the Book a Project form, collect all entered information and automatically create a WhatsApp message.

Use this format:

“Hello Deepanshu Digital Studio 👋

I’m interested in your services and would like to discuss a project.

📌 Name: [Name]
📧 Email: [Email]
📱 WhatsApp: [WhatsApp Number]
🛠️ Service: [Service Required]
📝 Project Details: [Project Details]
💰 Budget: [Budget]
📅 Preferred Deadline: [Preferred Deadline]

Please let me know the next steps. Thank you!”

Open WhatsApp using the official click-to-chat format with properly URL-encoded message text.

The WhatsApp button in the Contact section should directly open a WhatsApp chat with:

“Hello Deepanshu Digital Studio 👋
I’d like to discuss a project with you.”

Use:

https://wa.me/917876728918

If WhatsApp is installed, open the WhatsApp app where supported. Otherwise open WhatsApp Web/browser.

After redirecting the visitor to WhatsApp, show:

“Your project details are ready in WhatsApp. We’ll get back to you soon.”

Make sure:

* Form validation works before opening WhatsApp.
* Required fields cannot be empty.
* Message is properly URL encoded.
* Works on mobile and desktop.
* WhatsApp number is controlled from one configuration location.

CONTACT

Show:

Let’s Create Something Amazing.

Add:

WhatsApp: +91 7876728918
Email: dpgamingprox@gmail.com

Add buttons for:

* WhatsApp
* Instagram
* Email

Do not invent Instagram, YouTube or Facebook usernames. Keep them as editable placeholders until I provide them.

NAVIGATION

Sticky navbar:

Deepanshu Digital Studio

Home | Services | Projects | About | Contact

Right-side button:

Book a Project

FOOTER

Show:

Deepanshu Digital Studio

“Designing ideas. Creating impact.”

© 2026 Deepanshu Digital Studio. All Rights Reserved.

Add social media icons with editable placeholder links.

IMPORTANT FUNCTIONALITY

* Fully responsive on mobile, tablet and desktop.
* Fast loading.
* Smooth page transitions.
* Smooth scrolling.
* SEO-friendly structure.
* Optimized images.
* Working project booking form.
* Functional WhatsApp integration.
* Easy project management/update structure.
* Use clean reusable components.
* Keep personal details in one easy-to-edit configuration area.
* Never invent personal information.

The final website should look like a premium professional creative studio/agency website, not a generic freelancer template.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://deepanshudigitalstudio.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/347725aa-02d0-4a7b-b2fb-197f516ec20d).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
