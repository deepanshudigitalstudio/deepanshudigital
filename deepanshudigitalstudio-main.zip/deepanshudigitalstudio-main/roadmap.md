# Studio website
- [x] Build cinematic design, navigation and all requested content.
- [x] Add editable studio/project configuration and project detail views.
- [x] Implement validated WhatsApp booking and contact links.
- [x] Verify navigation, filters, form, mobile layout and metadata.