<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Studio architecture
- Keep personal details, social links and WhatsApp URL/message helpers in `src/config/studio.ts` so every contact action uses the same source.
- Manage portfolio entries in `src/config/projects.ts`, including optional video/website fields, so project updates never require gallery redesign.
- Use shared studio sections with semantic design tokens in `src/styles.css` so home and dedicated content pages stay visually consistent.
- Give each major content area its own TanStack route and leaf metadata for direct linking and search visibility.
- Send booking requests through client-side official WhatsApp click-to-chat after native and trimmed-field validation; no data storage or server is needed for this handoff.
