import { useState, type FormEvent } from 'react';
import { ArrowUpRight, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { studio, serviceOptions, bookingMessage, whatsappUrl, contactGreeting, type BookingDetails } from '@/config/studio';
import { Eyebrow } from './sections';
export function BookingSection() {
 const [sent,setSent]=useState(false);
 const [fallback,setFallback]=useState('');
 function submit(event:FormEvent<HTMLFormElement>) {
  event.preventDefault();
  const form=event.currentTarget;
  for (const el of Array.from(form.elements)) {
   if(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
    el.setCustomValidity(el.required&&!el.value.trim()?'Please fill out this field.':'');
   }
  }
  if(!form.reportValidity()) return;
  const fields=new FormData(form);
  const value=(key:string)=>String(fields.get(key)||'').trim();
  const data:BookingDetails={name:value('name'),email:value('email'),whatsapp:value('whatsapp'),service:value('service'),details:value('details'),budget:value('budget'),deadline:value('deadline')};
  const url=whatsappUrl(bookingMessage(data));
  window.open(url,'_blank','noopener,noreferrer');
  setFallback(url);setSent(true);
 }
 return <section className="section section-muted"><div className="studio-container booking-grid"><div className="booking-aside"><Eyebrow>Book a project</Eyebrow><h2>Your vision.<br/><span className="text-muted-foreground">Let’s bring it to life.</span></h2><p>Tell me what you have in mind. Your next creative project starts with a conversation.</p><div className="contact-detail"><small>WHATSAPP</small><a href={whatsappUrl(contactGreeting)} target="_blank" rel="noopener noreferrer">{studio.whatsappDisplay} <ArrowUpRight className="inline size-3"/></a></div><div className="contact-detail"><small>EMAIL</small><a href={`mailto:${studio.email}`}>{studio.email} <ArrowUpRight className="inline size-3"/></a></div></div><form className="booking-form" onSubmit={submit} onInput={event=>{const target=event.target;if(target instanceof HTMLInputElement||target instanceof HTMLTextAreaElement) target.setCustomValidity('');}}><div className="form-field"><label htmlFor="name">Name *</label><input id="name" name="name" autoComplete="name" placeholder="Your name" required maxLength={100}/></div><div className="form-field"><label htmlFor="email">Email *</label><input id="email" name="email" autoComplete="email" type="email" placeholder="you@example.com" required maxLength={200}/></div><div className="form-field"><label htmlFor="whatsapp">WhatsApp Number *</label><input id="whatsapp" name="whatsapp" autoComplete="tel" type="tel" placeholder="Your number with country code" pattern="[+0-9 ()\-]{7,20}" title="Enter 7–20 characters using digits, spaces, +, parentheses or hyphens." required/></div><div className="form-field"><label htmlFor="service">Service Required *</label><select id="service" name="service" required defaultValue=""><option value="" disabled>Select a service</option>{serviceOptions.map(s=><option key={s}>{s}</option>)}</select></div><div className="form-field field-full"><label htmlFor="details">Project Details *</label><textarea id="details" name="details" placeholder="Tell me about your project, ideas and goals…" required maxLength={4000}/></div><div className="form-field"><label htmlFor="budget">Budget *</label><input id="budget" name="budget" placeholder="Amount + currency, or to discuss" required maxLength={100}/></div><div className="form-field"><label htmlFor="deadline">Preferred Deadline *</label><input id="deadline" name="deadline" type="date" required/></div><div className="field-full"><Button type="submit" className="studio-button w-full">Send Project Request <ArrowUpRight/></Button><p className="form-note mt-3">Your request opens in WhatsApp. Review the message and tap send to start our conversation.</p></div>{sent&&<div className="form-success field-full" role="status"><p>Your project details are ready in WhatsApp. We’ll get back to you soon.</p><Button asChild variant="link" className="mt-2 p-0 h-auto"><a href={fallback} target="_blank" rel="noopener noreferrer"><MessageCircle/> Open WhatsApp again</a></Button></div>}</form></div></section>;
}
