import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, AboutSection, WhySection, ProcessSection, ContactBand } from '@/components/studio/sections';
import { studioHead } from '@/lib/studio-meta';
export const Route = createFileRoute('/about')({
 head:()=>studioHead('About Deepanshu','Meet Deepanshu, the designer and digital creator behind Deepanshu Digital Studio. Graphic design, video editing, branding and web creation with purpose.'),
 component:AboutPage,
});
function AboutPage(){return <div className="inner-page"><PageIntro eyebrow="Behind the studio" title="Creativity, with purpose." description="One creative mind. Many ways to bring your ideas to life."/><AboutSection/><WhySection/><ProcessSection/><ContactBand/></div>;}