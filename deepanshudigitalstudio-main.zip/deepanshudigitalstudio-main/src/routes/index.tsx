import { createFileRoute } from "@tanstack/react-router";
import { Hero, ServicesSection, ProjectsSection, AboutSection, WhySection, ProcessSection, ContactBand } from '@/components/studio/sections';
import { BookingSection } from '@/components/studio/booking';
import { studioHead } from '@/lib/studio-meta';
export const Route = createFileRoute("/")({
  head: () => studioHead('Creative Design, Powerful Visuals', 'Deepanshu Digital Studio creates graphic design, engaging videos, advertisements, branding and professional websites. Explore creative work and book your project.'),
  component: Index,
});
function Index() {
  return <><Hero/><ServicesSection/><ProjectsSection preview/><AboutSection/><WhySection/><ProcessSection/><BookingSection/><ContactBand/></>;
}
