import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, ProjectsSection, ContactBand } from '@/components/studio/sections';
import { studioHead } from '@/lib/studio-meta';
export const Route = createFileRoute('/projects')({
 head:()=>studioHead('Creative Portfolio','Explore graphic design, brand identity and advertising concepts from Deepanshu Digital Studio. Filter projects and discover the creative details.'),
 component:ProjectsPage,
});
function ProjectsPage(){return <div className="inner-page"><PageIntro eyebrow="The portfolio" title="Ideas. In their element." description="A collection of visual explorations. Different disciplines, one shared intention: create something worth noticing."/><ProjectsSection/><ContactBand/></div>;}