import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, ContactBand } from '@/components/studio/sections';
import { BookingSection } from '@/components/studio/booking';
import { studioHead } from '@/lib/studio-meta';
export const Route = createFileRoute('/contact')({
 head:()=>studioHead('Contact the Studio','Discuss your next design, video, advertising or website project with Deepanshu Digital Studio. Connect by WhatsApp or email.'),
 component:ContactPage,
});
function ContactPage(){return <div className="inner-page"><PageIntro eyebrow="Let’s connect" title="Let’s Create Something Amazing." description="A new idea, a fresh direction or a brand ready for its next chapter. I’d love to hear what you have in mind."/><BookingSection/><ContactBand/></div>;}