import { createFileRoute } from '@tanstack/react-router';
import { PageIntro } from '@/components/studio/sections';
import { BookingSection } from '@/components/studio/booking';
import { studioHead } from '@/lib/studio-meta';
export const Route = createFileRoute('/book')({
 head:()=>studioHead('Book a Project','Send your project brief, service, budget and deadline directly to Deepanshu Digital Studio through WhatsApp.'),
 component:BookPage,
});
function BookPage(){return <div className="inner-page"><PageIntro eyebrow="A new creative collaboration" title="Great work starts here." description="Share the details. Let’s turn your next idea into a distinctive visual experience."/><BookingSection/></div>;}