import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, ServicesSection, ProcessSection, ContactBand } from '@/components/studio/sections';
import { studioHead } from '@/lib/studio-meta';
export const Route = createFileRoute('/services')({
 head:()=>studioHead('Creative Services','Graphic design, video editing, advertisements, websites, social media content and branding crafted for your brand by Deepanshu.'),
 component:ServicesPage,
});
function ServicesPage(){return <div className="inner-page"><PageIntro eyebrow="What I do" title="Made to stand out." description="Thoughtful creative services for brands, businesses and creators. From a single visual to an entire digital experience."/><ServicesSection/><ProcessSection/><ContactBand/></div>;}