// Personal details and social links live here. Leave unknown links empty.
export const WHATSAPP_NUMBER = "917876728918";
export const studio = {
  name: "Deepanshu Digital Studio",
  owner: "Deepanshu",
  email: "dpgamingprox@gmail.com",
  whatsappDisplay: "+91 7876728918",
  profileImage: "", // Replace with a photo URL or imported image.
  socials: { instagram: "", youtube: "", facebook: "" },
};
export const serviceOptions = ["Graphic Design", "Video Editing", "Advertisement", "Website", "Branding", "Social Media Content", "Other"];
export const contactGreeting = "Hello Deepanshu Digital Studio 👋\nI’d like to discuss a project with you.";
export function whatsappUrl(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
export interface BookingDetails {
  name: string; email: string; whatsapp: string; service: string; details: string; budget: string; deadline: string;
}
export function bookingMessage(data: BookingDetails) {
  return `Hello Deepanshu Digital Studio 👋\n\nI’m interested in your services and would like to discuss a project.\n\n📌 Name: ${data.name.trim()}\n📧 Email: ${data.email.trim()}\n📱 WhatsApp: ${data.whatsapp.trim()}\n🛠️ Service: ${data.service}\n📝 Project Details: ${data.details.trim()}\n💰 Budget: ${data.budget.trim()}\n📅 Preferred Deadline: ${data.deadline}\n\nPlease let me know the next steps. Thank you!`;
}
