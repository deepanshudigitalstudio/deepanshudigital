import noise from '@/assets/noise-poster.webp';
import forma from '@/assets/forma-brand.webp';
import motion from '@/assets/motion-ad.webp';
import burger from '@/assets/burger-poster.jpg.asset.json';

export const projectCategories = ['All', 'Graphic Design', 'Video', 'Ads', 'Websites', 'Branding'] as const;
export type ProjectCategory = Exclude<(typeof projectCategories)[number], 'All'>;
export interface Project {
  id: string;
  name: string;
  category: ProjectCategory;
  description: string;
  image: string;
  imageAlt: string;
  concept?: boolean;
  video?: string;
  website?: string;
}
// Add, remove or edit projects here; the gallery and filters update automatically.
// These are illustrative concept projects, not claims of commissioned client work.
export const projects: Project[] = [
  { id: 'make-some-noise', name: 'Make Some Noise', category: 'Graphic Design', description: 'A bold visual concept that turns sound into a statement.', image: noise, imageAlt: 'Acid-yellow Make Some Noise music poster with black soundwave typography', concept: true },
  { id: 'forma', name: 'Forma — Brand Identity', category: 'Branding', description: 'A considered identity for a contemporary skincare concept.', image: forma, imageAlt: 'Forma skincare concept packaging in terracotta and blush', concept: true },
  { id: 'motion', name: 'Built for Motion', category: 'Ads', description: 'An energetic product campaign concept made to stand out.', image: motion, imageAlt: 'Floating athletic sneaker against an electric blue backdrop', concept: true },
  { id: 'burger-poster', name: 'Super Delicious — Burger Poster', category: 'Ads', description: 'A bold food delivery promotional poster with layered typography and flying ingredients.', image: burger.url, imageAlt: 'Super Delicious burger promotional poster with a flying double cheeseburger, sauce splash and bold red typography', },
];
