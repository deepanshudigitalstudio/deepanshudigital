import { describe, it, expect } from 'vitest';
import { bookingMessage, whatsappUrl, contactGreeting, WHATSAPP_NUMBER } from '@/config/studio';
describe('Studio WhatsApp',()=>{
 it('uses the configured number and encodes the complete brief safely',()=>{
  const data={name:' Test & Client ',email:'test@example.com',whatsapp:'+44 7700 900123',service:'Graphic Design',details:'Design A&B + 50% 🎨\nSecond line',budget:'₹25,000',deadline:'2026-11-12'};
  const message=bookingMessage(data);
  const url=new URL(whatsappUrl(message));
  expect(url.origin).toBe('https://wa.me');
  expect(url.pathname).toBe('/'+WHATSAPP_NUMBER);
  expect(url.searchParams.get('text')).toBe(message);
  expect(message).toContain('📌 Name: Test & Client');
  for(const value of [data.email,data.whatsapp,data.service,data.details,data.budget,data.deadline]) expect(message).toContain(value);
  expect(message).toContain('Please let me know the next steps. Thank you!');
 });
 it('uses the requested direct-contact greeting',()=>{
  expect(new URL(whatsappUrl(contactGreeting)).searchParams.get('text')).toBe('Hello Deepanshu Digital Studio 👋\nI’d like to discuss a project with you.');
 });
});